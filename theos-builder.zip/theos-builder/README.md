# Theos builder: Telegram bot + GitHub Actions

Send a Theos project to your Telegram bot, get the compiled `.dylib` back in the same chat.

```
You (Telegram) ──zip / git URL──▶ bot.py ──workflow_dispatch──▶ GitHub Actions (macOS runner)
        ▲                                                              │
        └────────────── .dylib (and .deb if asked) via Bot API ◀───────┘
```

- `.github/workflows/build.yml` installs Theos, compiles the project, and sends the result straight to Telegram.
- `bot/bot.py` is a tiny long-polling bot (Python 3.8+, no pip packages). It only starts the workflow; the zip never passes through it.

## One-time setup

### 1. Create the Telegram bot
1. In Telegram open **@BotFather** → `/newbot` → pick a name and username.
2. Copy the token it gives you (`123456789:AA...`). This is your `TELEGRAM_BOT_TOKEN`.

### 2. Put this repo on GitHub
1. Create a new repository (see "Public or private?" below).
2. Upload everything in this folder, keeping the structure. The workflow **must** be at `.github/workflows/build.yml` on your default branch.
   - Phone/web UI: *Add file → Create new file*, type `.github/workflows/build.yml` as the name (slashes create the folders) and paste the contents. Repeat for `bot/bot.py`.
   - PC: unzip, then `git init && git add . && git commit -m "init" && git remote add origin <url> && git push -u origin main`.

### 3. Give the workflow your bot token
Repo → **Settings → Secrets and variables → Actions → New repository secret**
- Name: `TELEGRAM_BOT_TOKEN`
- Value: the token from step 1

### 4. Create a GitHub token for the bot
GitHub → **Settings → Developer settings → Personal access tokens → Fine-grained tokens → Generate new token**
- Repository access: **Only select repositories** → your builder repo
- Repository permissions: **Actions: Read and write** (Metadata: Read is added automatically)
- Copy the token (`github_pat_...`). This is `GITHUB_PAT`.

### 5. Run the bot
1. Copy `bot/.env.example` to `bot/.env` and fill in `TELEGRAM_BOT_TOKEN`, `GITHUB_PAT` and `GITHUB_REPO` (`yourname/theos-builder`).
2. `cd bot && python3 bot.py`
3. Open your bot in Telegram and send `/id`. Put the number it replies with into `ALLOWED_USER_IDS` in `.env`, then restart the bot.

On startup the bot prints `Telegram OK` and `GitHub OK`. If GitHub shows a warning, the message says what is wrong (token, repo name, or branch).

If your default branch is not `main`, set `BUILD_REF=master` (or whatever it is) in `.env`.

### Where to run the bot
It has to stay running to hear your messages. Any of these work:
- Your PC, a VPS, or a Raspberry Pi: `python3 bot.py` (use `tmux`/`screen`/systemd to keep it alive).
- Android: Termux (`pkg install python`, then the same command).
- Container hosts (Koyeb, Render, Railway, Fly.io...): deploy the `bot/` folder with the included `Dockerfile` and set the `.env` values as environment variables.
- Shared PHP hosting such as InfinityFree can't run a Python process, so it isn't suitable for this bot.

## Using it

| You send | What happens |
|---|---|
| A `.zip` of the project folder | Built, `.dylib` comes back |
| `/build https://github.com/user/repo` | Clones and builds the repo |
| `/build https://github.com/user/repo dev --deb` | Same, branch `dev`, also sends the `.deb` |
| `/status` | Last 3 builds with links |

Options go in the zip's caption or after `/build`: `deb` (also send the .deb), `rootless` (`THEOS_PACKAGE_SCHEME=rootless`), `debug` (debug build instead of `FINALPACKAGE=1`). Both `deb` and `--deb` work.

The reply contains each `.dylib` with its architectures and size. If the build fails you get `build.log` plus the last lines of the error.

You can also run the workflow by hand: repo → **Actions → Theos Build → Run workflow** (use `source_type: git`).

## Limits worth knowing

- **Zip size:** bots can download files up to 20 MB. Delete `.theos/` and `packages/` before zipping, or use `/build` with a git URL.
- **Private git repos** are not supported by `/build`. Zip them instead.
- **Zip layout:** the Makefile closest to the top of the archive is used, so zipping the folder itself or its contents both work.
- **Needs a `control` file** (or `layout/DEBIAN/control`) for the staged, signed output. Without one it builds with plain `make` and returns `.theos/obj/*.dylib`.
- **Roothide:** not set up. It needs the roothide fork of Theos; swap the `git clone` URL in the "Install Theos" step if you need it.
- **Runner:** `macos-15` is pinned for stability. `macos-latest` is moving to macOS 26, so change `runs-on` only if you need a newer Xcode.

## Public or private repo?

- **Public:** GitHub-hosted runners are free. Anyone can read the workflow runs and logs (build output only, never your bot token), so don't build code you want to keep private through it.
- **Private:** logs stay private, but builds use your monthly free Actions minutes, and macOS minutes are charged at a higher rate than Linux. Check GitHub's current pricing page for your plan.

## Security notes

- Only the Telegram IDs in `ALLOWED_USER_IDS` can start builds. Anyone else gets a refusal.
- The build runs your project's Makefile, which can execute arbitrary commands. That is expected for your own code, so don't build projects you don't trust. The bot token is only given to the download and upload steps, never to the build step.
- Keep `.env` private (it is in `.gitignore`). If a token leaks, revoke it (BotFather `/revoke`, or delete the GitHub token) and make a new one.

## Troubleshooting

| Symptom | Fix |
|---|---|
| Bot says `HTTP 404` when starting a build | `GITHUB_REPO` is wrong, or the token isn't scoped to that repo |
| `HTTP 403` | Token needs **Actions: Read and write** |
| `HTTP 422` | `build.yml` isn't on the branch in `BUILD_REF` |
| Nothing arrives after "Queued" | Check the Actions tab; make sure the `TELEGRAM_BOT_TOKEN` secret exists |
| `Conflict: terminated by other getUpdates` | Two copies of the bot are running; stop one |
| "No Makefile found" | Zip the project folder, not its parent |
